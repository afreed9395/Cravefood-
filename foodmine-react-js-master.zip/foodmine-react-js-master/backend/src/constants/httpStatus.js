export const BAD_REQUEST = 400;
export const UNAUTHORIZED = 401;
